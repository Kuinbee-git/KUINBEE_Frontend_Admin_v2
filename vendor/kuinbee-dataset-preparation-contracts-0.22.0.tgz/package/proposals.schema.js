"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DatasetAdminAssignmentsResponseSchema = exports.DatasetAdminProposalsResponseSchema = exports.DatasetSupplierProposalsResponseSchema = exports.DatasetAdminProposalListItemSchema = exports.DatasetAdminDatasetListItemSchema = exports.DatasetProposalListItemSchema = exports.DatasetAdminAssignmentsQuerySchema = exports.DatasetAdminProposalsQuerySchema = exports.DatasetSupplierProposalsQuerySchema = void 0;
const zod_1 = require("zod");
const preparation_schema_1 = require("./preparation.schema");
const workflow_schema_1 = require("./workflow.schema");
const id = zod_1.z.string().cuid();
const pageNumber = (max) => zod_1.z.union([zod_1.z.number().int().min(1).max(max),
    zod_1.z.string().regex(/^[1-9][0-9]*$/).transform(Number).pipe(zod_1.z.number().int().min(1).max(max))]);
const pagination = { page: pageNumber(1_000).default(1), pageSize: pageNumber(50).default(20) };
const filters = { ...pagination, q: zod_1.z.string().trim().min(1).max(200).optional(),
    status: workflow_schema_1.DatasetWorkflowStateSchema.shape.datasetStatus.optional(),
    verificationStatus: workflow_schema_1.DatasetWorkflowStateSchema.shape.verificationStatus.optional() };
const reviewQueue = zod_1.z.enum(["ALL", "PROPOSALS", "UPDATES"]).default("ALL");
exports.DatasetSupplierProposalsQuerySchema = zod_1.z.object({ ...filters,
    scope: zod_1.z.enum(["SUBMITTED", "ALL"]).default("SUBMITTED") }).strict();
exports.DatasetAdminProposalsQuerySchema = zod_1.z.object({ ...filters,
    reviewQueue,
    assignedTo: zod_1.z.enum(["ANY", "ME", "UNASSIGNED"]).default("ANY"),
    sort: zod_1.z.enum(["createdAt:asc", "createdAt:desc", "updatedAt:asc", "updatedAt:desc"]).default("createdAt:desc") }).strict();
exports.DatasetAdminAssignmentsQuerySchema = zod_1.z.object({ ...pagination,
    reviewQueue,
    status: zod_1.z.enum(["ACTIVE", "COMPLETED", "REASSIGNED", "CANCELLED", "ALL"]).default("ACTIVE"),
    sort: zod_1.z.enum(["assignedAt:asc", "assignedAt:desc", "completedAt:asc", "completedAt:desc"]).default("assignedAt:desc") }).strict();
const material = zod_1.z.discriminatedUnion("representation", [
    zod_1.z.object({ representation: zod_1.z.literal("LEGACY"), currentUploadId: zod_1.z.string().min(1).nullable() }).strict(),
    zod_1.z.object({ representation: zod_1.z.literal("CONTENT"), activeContentId: id.nullable(), reviewedContentId: id.nullable(),
        publishedContentId: id.nullable(), uploadChoice: preparation_schema_1.DatasetUploadChoiceSchema.nullable(), workflowRevision: zod_1.z.number().int().nonnegative() }).strict(),
]);
// Current list facts only. The exact review response supplies frozen facts;
// neither legacy isSample nor a current upload pointer proves file readiness.
exports.DatasetProposalListItemSchema = zod_1.z.object({
    id, datasetUniqueId: zod_1.z.string().min(1), title: zod_1.z.string().min(1),
    status: workflow_schema_1.DatasetWorkflowStateSchema.shape.datasetStatus,
    verificationStatus: workflow_schema_1.DatasetWorkflowStateSchema.shape.verificationStatus.nullable(),
    primaryCategory: zod_1.z.object({ id: zod_1.z.string().min(1), name: zod_1.z.string().min(1) }).strict().nullable(),
    material, createdAt: zod_1.z.string().datetime(), updatedAt: zod_1.z.string().datetime(),
}).strict();
const assignment = zod_1.z.object({ id, adminId: id, status: zod_1.z.enum(["ACTIVE", "COMPLETED", "REASSIGNED", "CANCELLED"]),
    assignedAt: zod_1.z.string().datetime(), completedAt: zod_1.z.string().datetime().nullable() }).strict();
const supplier = zod_1.z.object({ id, email: zod_1.z.string().email() }).strict().nullable();
exports.DatasetAdminDatasetListItemSchema = exports.DatasetProposalListItemSchema.extend({
    // Legacy keeps its original overlapping queue behavior; never invent a
    // canonical correction context for a legacy file proposal.
    managementContext: zod_1.z.enum(["INITIAL_PROPOSAL", "MANAGED"]).nullable(),
    submittedAt: zod_1.z.string().datetime().nullable(),
}).refine(value => (value.material.representation === "LEGACY") === (value.managementContext === null), "Only canonical content has a correction management context");
exports.DatasetAdminProposalListItemSchema = exports.DatasetAdminDatasetListItemSchema.safeExtend({ supplier, activeAssignment: assignment.nullable() });
const response = { page: zod_1.z.number().int().positive(), pageSize: zod_1.z.number().int().positive().max(50), total: zod_1.z.number().int().nonnegative() };
exports.DatasetSupplierProposalsResponseSchema = zod_1.z.object({ ...response, items: zod_1.z.array(exports.DatasetProposalListItemSchema).max(50),
    summary: zod_1.z.object({ total: zod_1.z.number().int().nonnegative(), byVerificationStatus: zod_1.z.object({
            SUBMITTED: zod_1.z.number().int().nonnegative(), CHANGES_REQUESTED: zod_1.z.number().int().nonnegative(),
            RESUBMITTED: zod_1.z.number().int().nonnegative(), UNDER_REVIEW: zod_1.z.number().int().nonnegative(),
            VERIFIED: zod_1.z.number().int().nonnegative(), REJECTED: zod_1.z.number().int().nonnegative(),
        }).strict() }).strict(),
}).strict();
exports.DatasetAdminProposalsResponseSchema = zod_1.z.object({ ...response, items: zod_1.z.array(exports.DatasetAdminProposalListItemSchema).max(50) }).strict();
exports.DatasetAdminAssignmentsResponseSchema = zod_1.z.object({ ...response,
    items: zod_1.z.array(zod_1.z.object({ assignment, dataset: exports.DatasetAdminDatasetListItemSchema, supplier }).strict()).max(50) }).strict();
