import { z } from "zod";
export declare const DATASET_UPLOAD_FILE_LIMIT_BYTES: "2000000000";
export declare const DatasetUploadAdmissionBodySchema: z.ZodObject<{
    component: z.ZodEnum<{
        FULL: "FULL";
        SAMPLE: "SAMPLE";
    }>;
    role: z.ZodEnum<{
        PRIMARY: "PRIMARY";
        TRANSCRIPT: "TRANSCRIPT";
        ANNOTATION: "ANNOTATION";
        SENSOR: "SENSOR";
        CALIBRATION: "CALIBRATION";
        DOCUMENTATION: "DOCUMENTATION";
    }>;
    inspectionProfile: z.ZodUnion<readonly [z.ZodDiscriminatedUnion<[z.ZodObject<{
        profileId: z.ZodEnum<{
            UTF8_CSV_SYNTAX_V1: "UTF8_CSV_SYNTAX_V1";
            UTF8_TSV_SYNTAX_V1: "UTF8_TSV_SYNTAX_V1";
        }>;
        header: z.ZodEnum<{
            PRESENT: "PRESENT";
            ABSENT: "ABSENT";
        }>;
    }, z.core.$strict>, z.ZodObject<{
        profileId: z.ZodLiteral<"UTF8_JSONL_SYNTAX_V1">;
        recordKind: z.ZodEnum<{
            OBJECT: "OBJECT";
            OBJECT_OR_ARRAY: "OBJECT_OR_ARRAY";
        }>;
    }, z.core.$strict>, z.ZodObject<{
        profileId: z.ZodLiteral<"RIFF_INTEGER_PCM_WAVE_V1">;
    }, z.core.$strict>, z.ZodObject<{
        profileId: z.ZodLiteral<"PNG_STATIC_8BIT_V1">;
    }, z.core.$strict>, z.ZodObject<{
        profileId: z.ZodLiteral<"JPEG_BASELINE_STRUCTURE_V1">;
    }, z.core.$strict>], "profileId">, z.ZodObject<{
        profileId: z.ZodLiteral<"ZIP32_CONTAINER_V1">;
        leafProfiles: z.ZodArray<z.ZodObject<{
            locator: z.ZodDiscriminatedUnion<[z.ZodObject<{
                kind: z.ZodLiteral<"ARCHIVE_ENTRY">;
                path: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                kind: z.ZodLiteral<"WORKBOOK_SHEET">;
                sheetName: z.ZodString;
            }, z.core.$strict>], "kind"> & z.ZodType<{
                kind: "ARCHIVE_ENTRY";
                path: string;
            }, {
                kind: "ARCHIVE_ENTRY";
                path: string;
            } | {
                kind: "WORKBOOK_SHEET";
                sheetName: string;
            }, z.core.$ZodTypeInternals<{
                kind: "ARCHIVE_ENTRY";
                path: string;
            }, {
                kind: "ARCHIVE_ENTRY";
                path: string;
            } | {
                kind: "WORKBOOK_SHEET";
                sheetName: string;
            }>>;
            profile: z.ZodDiscriminatedUnion<[z.ZodObject<{
                profileId: z.ZodEnum<{
                    UTF8_CSV_SYNTAX_V1: "UTF8_CSV_SYNTAX_V1";
                    UTF8_TSV_SYNTAX_V1: "UTF8_TSV_SYNTAX_V1";
                }>;
                header: z.ZodEnum<{
                    PRESENT: "PRESENT";
                    ABSENT: "ABSENT";
                }>;
            }, z.core.$strict>, z.ZodObject<{
                profileId: z.ZodLiteral<"UTF8_JSONL_SYNTAX_V1">;
                recordKind: z.ZodEnum<{
                    OBJECT: "OBJECT";
                    OBJECT_OR_ARRAY: "OBJECT_OR_ARRAY";
                }>;
            }, z.core.$strict>, z.ZodObject<{
                profileId: z.ZodLiteral<"RIFF_INTEGER_PCM_WAVE_V1">;
            }, z.core.$strict>, z.ZodObject<{
                profileId: z.ZodLiteral<"PNG_STATIC_8BIT_V1">;
            }, z.core.$strict>, z.ZodObject<{
                profileId: z.ZodLiteral<"JPEG_BASELINE_STRUCTURE_V1">;
            }, z.core.$strict>], "profileId">;
        }, z.core.$strict>>;
        entryDefaults: z.ZodOptional<z.ZodArray<z.ZodObject<{
            extension: z.ZodString;
            profile: z.ZodDiscriminatedUnion<[z.ZodObject<{
                profileId: z.ZodEnum<{
                    UTF8_CSV_SYNTAX_V1: "UTF8_CSV_SYNTAX_V1";
                    UTF8_TSV_SYNTAX_V1: "UTF8_TSV_SYNTAX_V1";
                }>;
                header: z.ZodEnum<{
                    PRESENT: "PRESENT";
                    ABSENT: "ABSENT";
                }>;
            }, z.core.$strict>, z.ZodObject<{
                profileId: z.ZodLiteral<"UTF8_JSONL_SYNTAX_V1">;
                recordKind: z.ZodEnum<{
                    OBJECT: "OBJECT";
                    OBJECT_OR_ARRAY: "OBJECT_OR_ARRAY";
                }>;
            }, z.core.$strict>, z.ZodObject<{
                profileId: z.ZodLiteral<"RIFF_INTEGER_PCM_WAVE_V1">;
            }, z.core.$strict>, z.ZodObject<{
                profileId: z.ZodLiteral<"PNG_STATIC_8BIT_V1">;
            }, z.core.$strict>, z.ZodObject<{
                profileId: z.ZodLiteral<"JPEG_BASELINE_STRUCTURE_V1">;
            }, z.core.$strict>], "profileId">;
        }, z.core.$strict>>>;
    }, z.core.$strict>]>;
    originalName: z.ZodString;
    claimedMime: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    expectedBytes: z.ZodString;
    expectedPreparationGeneration: z.ZodNumber;
    expectedContentId: z.ZodString;
    expectedContentGeneration: z.ZodNumber;
    requestId: z.ZodPipe<z.ZodString, z.ZodTransform<string, string>>;
}, z.core.$strict>;
export declare const DatasetUploadActionBodySchema: z.ZodObject<{
    expectedPreparationGeneration: z.ZodNumber;
    expectedContentId: z.ZodString;
    expectedContentGeneration: z.ZodNumber;
    requestId: z.ZodPipe<z.ZodString, z.ZodTransform<string, string>>;
}, z.core.$strict>;
export declare const DatasetUploadCancelBodySchema: z.ZodObject<{
    requestId: z.ZodPipe<z.ZodString, z.ZodTransform<string, string>>;
    expectedAttemptRevision: z.ZodNumber;
    expectedRecoveryEpoch: z.ZodNumber;
}, z.core.$strict>;
export declare const DatasetUploadAttemptResponseSchema: z.ZodObject<{
    requestId: z.ZodOptional<z.ZodPipe<z.ZodString, z.ZodTransform<string, string>>>;
    id: z.ZodString;
    rootId: z.ZodString;
    contentId: z.ZodString;
    component: z.ZodEnum<{
        FULL: "FULL";
        SAMPLE: "SAMPLE";
    }>;
    role: z.ZodEnum<{
        PRIMARY: "PRIMARY";
        TRANSCRIPT: "TRANSCRIPT";
        ANNOTATION: "ANNOTATION";
        SENSOR: "SENSOR";
        CALIBRATION: "CALIBRATION";
        DOCUMENTATION: "DOCUMENTATION";
    }>;
    inspectionProfile: z.ZodOptional<z.ZodUnion<readonly [z.ZodDiscriminatedUnion<[z.ZodObject<{
        profileId: z.ZodEnum<{
            UTF8_CSV_SYNTAX_V1: "UTF8_CSV_SYNTAX_V1";
            UTF8_TSV_SYNTAX_V1: "UTF8_TSV_SYNTAX_V1";
        }>;
        header: z.ZodEnum<{
            PRESENT: "PRESENT";
            ABSENT: "ABSENT";
        }>;
    }, z.core.$strict>, z.ZodObject<{
        profileId: z.ZodLiteral<"UTF8_JSONL_SYNTAX_V1">;
        recordKind: z.ZodEnum<{
            OBJECT: "OBJECT";
            OBJECT_OR_ARRAY: "OBJECT_OR_ARRAY";
        }>;
    }, z.core.$strict>, z.ZodObject<{
        profileId: z.ZodLiteral<"RIFF_INTEGER_PCM_WAVE_V1">;
    }, z.core.$strict>, z.ZodObject<{
        profileId: z.ZodLiteral<"PNG_STATIC_8BIT_V1">;
    }, z.core.$strict>, z.ZodObject<{
        profileId: z.ZodLiteral<"JPEG_BASELINE_STRUCTURE_V1">;
    }, z.core.$strict>], "profileId">, z.ZodObject<{
        profileId: z.ZodLiteral<"ZIP32_CONTAINER_V1">;
        leafProfiles: z.ZodArray<z.ZodObject<{
            locator: z.ZodDiscriminatedUnion<[z.ZodObject<{
                kind: z.ZodLiteral<"ARCHIVE_ENTRY">;
                path: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                kind: z.ZodLiteral<"WORKBOOK_SHEET">;
                sheetName: z.ZodString;
            }, z.core.$strict>], "kind"> & z.ZodType<{
                kind: "ARCHIVE_ENTRY";
                path: string;
            }, {
                kind: "ARCHIVE_ENTRY";
                path: string;
            } | {
                kind: "WORKBOOK_SHEET";
                sheetName: string;
            }, z.core.$ZodTypeInternals<{
                kind: "ARCHIVE_ENTRY";
                path: string;
            }, {
                kind: "ARCHIVE_ENTRY";
                path: string;
            } | {
                kind: "WORKBOOK_SHEET";
                sheetName: string;
            }>>;
            profile: z.ZodDiscriminatedUnion<[z.ZodObject<{
                profileId: z.ZodEnum<{
                    UTF8_CSV_SYNTAX_V1: "UTF8_CSV_SYNTAX_V1";
                    UTF8_TSV_SYNTAX_V1: "UTF8_TSV_SYNTAX_V1";
                }>;
                header: z.ZodEnum<{
                    PRESENT: "PRESENT";
                    ABSENT: "ABSENT";
                }>;
            }, z.core.$strict>, z.ZodObject<{
                profileId: z.ZodLiteral<"UTF8_JSONL_SYNTAX_V1">;
                recordKind: z.ZodEnum<{
                    OBJECT: "OBJECT";
                    OBJECT_OR_ARRAY: "OBJECT_OR_ARRAY";
                }>;
            }, z.core.$strict>, z.ZodObject<{
                profileId: z.ZodLiteral<"RIFF_INTEGER_PCM_WAVE_V1">;
            }, z.core.$strict>, z.ZodObject<{
                profileId: z.ZodLiteral<"PNG_STATIC_8BIT_V1">;
            }, z.core.$strict>, z.ZodObject<{
                profileId: z.ZodLiteral<"JPEG_BASELINE_STRUCTURE_V1">;
            }, z.core.$strict>], "profileId">;
        }, z.core.$strict>>;
        entryDefaults: z.ZodOptional<z.ZodArray<z.ZodObject<{
            extension: z.ZodString;
            profile: z.ZodDiscriminatedUnion<[z.ZodObject<{
                profileId: z.ZodEnum<{
                    UTF8_CSV_SYNTAX_V1: "UTF8_CSV_SYNTAX_V1";
                    UTF8_TSV_SYNTAX_V1: "UTF8_TSV_SYNTAX_V1";
                }>;
                header: z.ZodEnum<{
                    PRESENT: "PRESENT";
                    ABSENT: "ABSENT";
                }>;
            }, z.core.$strict>, z.ZodObject<{
                profileId: z.ZodLiteral<"UTF8_JSONL_SYNTAX_V1">;
                recordKind: z.ZodEnum<{
                    OBJECT: "OBJECT";
                    OBJECT_OR_ARRAY: "OBJECT_OR_ARRAY";
                }>;
            }, z.core.$strict>, z.ZodObject<{
                profileId: z.ZodLiteral<"RIFF_INTEGER_PCM_WAVE_V1">;
            }, z.core.$strict>, z.ZodObject<{
                profileId: z.ZodLiteral<"PNG_STATIC_8BIT_V1">;
            }, z.core.$strict>, z.ZodObject<{
                profileId: z.ZodLiteral<"JPEG_BASELINE_STRUCTURE_V1">;
            }, z.core.$strict>], "profileId">;
        }, z.core.$strict>>>;
    }, z.core.$strict>]>>;
    originalName: z.ZodString;
    expectedBytes: z.ZodString;
    retainedBytes: z.ZodString;
    reservedBytes: z.ZodString;
    partBytes: z.ZodNumber;
    totalParts: z.ZodNumber;
    state: z.ZodEnum<{
        ADMITTED: "ADMITTED";
        RECEIVING: "RECEIVING";
        FINALIZING: "FINALIZING";
        RECEIVED: "RECEIVED";
        CHECKING: "CHECKING";
        ACCEPTED: "ACCEPTED";
        REJECTED: "REJECTED";
        CANCEL_REQUESTED: "CANCEL_REQUESTED";
        RECONCILIATION_REQUIRED: "RECONCILIATION_REQUIRED";
        CLOSED: "CLOSED";
    }>;
    revision: z.ZodNumber;
    recoveryEpoch: z.ZodOptional<z.ZodNumber>;
    expiresAt: z.ZodString;
    eligibility: z.ZodLiteral<"NOT_ACCEPTED">;
}, z.core.$strict>;
export declare const DatasetUploadAttemptStatusResponseSchema: z.ZodObject<{
    component: z.ZodEnum<{
        FULL: "FULL";
        SAMPLE: "SAMPLE";
    }>;
    role: z.ZodEnum<{
        PRIMARY: "PRIMARY";
        TRANSCRIPT: "TRANSCRIPT";
        ANNOTATION: "ANNOTATION";
        SENSOR: "SENSOR";
        CALIBRATION: "CALIBRATION";
        DOCUMENTATION: "DOCUMENTATION";
    }>;
    inspectionProfile: z.ZodNonOptional<z.ZodOptional<z.ZodUnion<readonly [z.ZodDiscriminatedUnion<[z.ZodObject<{
        profileId: z.ZodEnum<{
            UTF8_CSV_SYNTAX_V1: "UTF8_CSV_SYNTAX_V1";
            UTF8_TSV_SYNTAX_V1: "UTF8_TSV_SYNTAX_V1";
        }>;
        header: z.ZodEnum<{
            PRESENT: "PRESENT";
            ABSENT: "ABSENT";
        }>;
    }, z.core.$strict>, z.ZodObject<{
        profileId: z.ZodLiteral<"UTF8_JSONL_SYNTAX_V1">;
        recordKind: z.ZodEnum<{
            OBJECT: "OBJECT";
            OBJECT_OR_ARRAY: "OBJECT_OR_ARRAY";
        }>;
    }, z.core.$strict>, z.ZodObject<{
        profileId: z.ZodLiteral<"RIFF_INTEGER_PCM_WAVE_V1">;
    }, z.core.$strict>, z.ZodObject<{
        profileId: z.ZodLiteral<"PNG_STATIC_8BIT_V1">;
    }, z.core.$strict>, z.ZodObject<{
        profileId: z.ZodLiteral<"JPEG_BASELINE_STRUCTURE_V1">;
    }, z.core.$strict>], "profileId">, z.ZodObject<{
        profileId: z.ZodLiteral<"ZIP32_CONTAINER_V1">;
        leafProfiles: z.ZodArray<z.ZodObject<{
            locator: z.ZodDiscriminatedUnion<[z.ZodObject<{
                kind: z.ZodLiteral<"ARCHIVE_ENTRY">;
                path: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                kind: z.ZodLiteral<"WORKBOOK_SHEET">;
                sheetName: z.ZodString;
            }, z.core.$strict>], "kind"> & z.ZodType<{
                kind: "ARCHIVE_ENTRY";
                path: string;
            }, {
                kind: "ARCHIVE_ENTRY";
                path: string;
            } | {
                kind: "WORKBOOK_SHEET";
                sheetName: string;
            }, z.core.$ZodTypeInternals<{
                kind: "ARCHIVE_ENTRY";
                path: string;
            }, {
                kind: "ARCHIVE_ENTRY";
                path: string;
            } | {
                kind: "WORKBOOK_SHEET";
                sheetName: string;
            }>>;
            profile: z.ZodDiscriminatedUnion<[z.ZodObject<{
                profileId: z.ZodEnum<{
                    UTF8_CSV_SYNTAX_V1: "UTF8_CSV_SYNTAX_V1";
                    UTF8_TSV_SYNTAX_V1: "UTF8_TSV_SYNTAX_V1";
                }>;
                header: z.ZodEnum<{
                    PRESENT: "PRESENT";
                    ABSENT: "ABSENT";
                }>;
            }, z.core.$strict>, z.ZodObject<{
                profileId: z.ZodLiteral<"UTF8_JSONL_SYNTAX_V1">;
                recordKind: z.ZodEnum<{
                    OBJECT: "OBJECT";
                    OBJECT_OR_ARRAY: "OBJECT_OR_ARRAY";
                }>;
            }, z.core.$strict>, z.ZodObject<{
                profileId: z.ZodLiteral<"RIFF_INTEGER_PCM_WAVE_V1">;
            }, z.core.$strict>, z.ZodObject<{
                profileId: z.ZodLiteral<"PNG_STATIC_8BIT_V1">;
            }, z.core.$strict>, z.ZodObject<{
                profileId: z.ZodLiteral<"JPEG_BASELINE_STRUCTURE_V1">;
            }, z.core.$strict>], "profileId">;
        }, z.core.$strict>>;
        entryDefaults: z.ZodOptional<z.ZodArray<z.ZodObject<{
            extension: z.ZodString;
            profile: z.ZodDiscriminatedUnion<[z.ZodObject<{
                profileId: z.ZodEnum<{
                    UTF8_CSV_SYNTAX_V1: "UTF8_CSV_SYNTAX_V1";
                    UTF8_TSV_SYNTAX_V1: "UTF8_TSV_SYNTAX_V1";
                }>;
                header: z.ZodEnum<{
                    PRESENT: "PRESENT";
                    ABSENT: "ABSENT";
                }>;
            }, z.core.$strict>, z.ZodObject<{
                profileId: z.ZodLiteral<"UTF8_JSONL_SYNTAX_V1">;
                recordKind: z.ZodEnum<{
                    OBJECT: "OBJECT";
                    OBJECT_OR_ARRAY: "OBJECT_OR_ARRAY";
                }>;
            }, z.core.$strict>, z.ZodObject<{
                profileId: z.ZodLiteral<"RIFF_INTEGER_PCM_WAVE_V1">;
            }, z.core.$strict>, z.ZodObject<{
                profileId: z.ZodLiteral<"PNG_STATIC_8BIT_V1">;
            }, z.core.$strict>, z.ZodObject<{
                profileId: z.ZodLiteral<"JPEG_BASELINE_STRUCTURE_V1">;
            }, z.core.$strict>], "profileId">;
        }, z.core.$strict>>>;
    }, z.core.$strict>]>>>;
    originalName: z.ZodString;
    expectedBytes: z.ZodString;
    id: z.ZodString;
    rootId: z.ZodString;
    contentId: z.ZodString;
    revision: z.ZodNumber;
    retainedBytes: z.ZodString;
    reservedBytes: z.ZodString;
    partBytes: z.ZodNumber;
    totalParts: z.ZodNumber;
    state: z.ZodEnum<{
        ADMITTED: "ADMITTED";
        RECEIVING: "RECEIVING";
        FINALIZING: "FINALIZING";
        RECEIVED: "RECEIVED";
        CHECKING: "CHECKING";
        ACCEPTED: "ACCEPTED";
        REJECTED: "REJECTED";
        CANCEL_REQUESTED: "CANCEL_REQUESTED";
        RECONCILIATION_REQUIRED: "RECONCILIATION_REQUIRED";
        CLOSED: "CLOSED";
    }>;
    recoveryEpoch: z.ZodNonOptional<z.ZodOptional<z.ZodNumber>>;
    expiresAt: z.ZodString;
    eligibility: z.ZodEnum<{
        ACCEPTED: "ACCEPTED";
        NOT_ACCEPTED: "NOT_ACCEPTED";
    }>;
    uploadObjectId: z.ZodOptional<z.ZodNullable<z.ZodString>>;
}, z.core.$strict>;
export declare const DATASET_UPLOAD_STATUS_PAGE_MAX = 50;
export declare const DatasetIntakeConfigQuerySchema: z.ZodObject<{
    expectedPreparationGeneration: z.ZodUnion<readonly [z.ZodNumber, z.ZodPipe<z.ZodPipe<z.ZodString, z.ZodTransform<number, string>>, z.ZodNumber>]>;
}, z.core.$strict>;
export declare const DatasetIntakeProfileSchema: z.ZodEnum<{
    UTF8_CSV_SYNTAX_V1: "UTF8_CSV_SYNTAX_V1";
    UTF8_TSV_SYNTAX_V1: "UTF8_TSV_SYNTAX_V1";
    UTF8_JSONL_SYNTAX_V1: "UTF8_JSONL_SYNTAX_V1";
    RIFF_INTEGER_PCM_WAVE_V1: "RIFF_INTEGER_PCM_WAVE_V1";
    PNG_STATIC_8BIT_V1: "PNG_STATIC_8BIT_V1";
    ZIP32_CONTAINER_V1: "ZIP32_CONTAINER_V1";
}>;
export declare const DatasetIntakeCapabilitySchema: z.ZodObject<{
    profileId: z.ZodEnum<{
        UTF8_CSV_SYNTAX_V1: "UTF8_CSV_SYNTAX_V1";
        UTF8_TSV_SYNTAX_V1: "UTF8_TSV_SYNTAX_V1";
        UTF8_JSONL_SYNTAX_V1: "UTF8_JSONL_SYNTAX_V1";
        RIFF_INTEGER_PCM_WAVE_V1: "RIFF_INTEGER_PCM_WAVE_V1";
        PNG_STATIC_8BIT_V1: "PNG_STATIC_8BIT_V1";
        ZIP32_CONTAINER_V1: "ZIP32_CONTAINER_V1";
    }>;
    maximumObjectBytes: z.ZodString;
    choices: z.ZodTuple<[z.ZodLiteral<"SAMPLE_ONLY">, z.ZodLiteral<"FULL_ONLY">, z.ZodLiteral<"FULL_AND_SAMPLE">], null>;
    extensions: z.ZodArray<z.ZodString>;
    mimeTypes: z.ZodArray<z.ZodString>;
}, z.core.$strict>;
export declare const DatasetIntakeTransportSchema: z.ZodObject<{
    kind: z.ZodLiteral<"BOUNDED_PARTS_V1">;
    partBytes: z.ZodNumber;
    maximumParts: z.ZodLiteral<10000>;
    mediaType: z.ZodLiteral<"application/octet-stream">;
    partPathTemplate: z.ZodLiteral<"/api/v2/supplier/dataset-drafts/{draftId}/uploads/{attemptId}/parts/{partNumber}">;
}, z.core.$strict>;
export declare const DatasetIntakeConfigResponseSchema: z.ZodObject<{
    context: z.ZodObject<{
        contractVersion: z.ZodLiteral<1>;
        requestId: z.ZodOptional<z.ZodPipe<z.ZodString, z.ZodTransform<string, string>>>;
        preparationId: z.ZodString;
        preparationGeneration: z.ZodNumber;
        contentId: z.ZodNullable<z.ZodString>;
        contentGeneration: z.ZodNullable<z.ZodNumber>;
        sourcePreparationGeneration: z.ZodNullable<z.ZodNumber>;
        serverUploadChoice: z.ZodNullable<z.ZodEnum<{
            SAMPLE_ONLY: "SAMPLE_ONLY";
            FULL_ONLY: "FULL_ONLY";
            FULL_AND_SAMPLE: "FULL_AND_SAMPLE";
        }>>;
        editable: z.ZodBoolean;
        synchronizationRequired: z.ZodBoolean;
        usage: z.ZodObject<{
            state: z.ZodEnum<{
                UNAVAILABLE: "UNAVAILABLE";
                RECONCILING: "RECONCILING";
                ACCOUNTED: "ACCOUNTED";
            }>;
            dataset: z.ZodObject<{
                limitBytes: z.ZodLiteral<"5000000000" | "100000000000">;
                retainedBytes: z.ZodNullable<z.ZodString>;
                reservedBytes: z.ZodNullable<z.ZodString>;
                chargedBytes: z.ZodNullable<z.ZodString>;
                remainingBytes: z.ZodNullable<z.ZodString>;
            }, z.core.$strict>;
            supplier: z.ZodObject<{
                limitBytes: z.ZodLiteral<"5000000000" | "100000000000">;
                retainedBytes: z.ZodNullable<z.ZodString>;
                reservedBytes: z.ZodNullable<z.ZodString>;
                chargedBytes: z.ZodNullable<z.ZodString>;
                remainingBytes: z.ZodNullable<z.ZodString>;
            }, z.core.$strict>;
        }, z.core.$strict>;
        admission: z.ZodObject<{
            enabled: z.ZodLiteral<false>;
            reason: z.ZodLiteral<"INTAKE_NOT_ENABLED">;
        }, z.core.$strict>;
    }, z.core.$strict>;
    maximumFileBytes: z.ZodLiteral<"2000000000">;
    admission: z.ZodDiscriminatedUnion<[z.ZodObject<{
        enabled: z.ZodLiteral<false>;
        reason: z.ZodEnum<{
            INTAKE_NOT_CONFIGURED: "INTAKE_NOT_CONFIGURED";
            INTAKE_NOT_QUALIFIED: "INTAKE_NOT_QUALIFIED";
            CAPACITY_UNAVAILABLE: "CAPACITY_UNAVAILABLE";
            CAPACITY_RECONCILIATION_REQUIRED: "CAPACITY_RECONCILIATION_REQUIRED";
            DRAFT_NOT_READY: "DRAFT_NOT_READY";
            INTAKE_PAUSED: "INTAKE_PAUSED";
        }>;
        policyVersion: z.ZodNullable<z.ZodString>;
    }, z.core.$strict>, z.ZodObject<{
        enabled: z.ZodLiteral<true>;
        reason: z.ZodNull;
        policyVersion: z.ZodString;
    }, z.core.$strict>], "enabled">;
    capabilities: z.ZodArray<z.ZodObject<{
        profileId: z.ZodEnum<{
            UTF8_CSV_SYNTAX_V1: "UTF8_CSV_SYNTAX_V1";
            UTF8_TSV_SYNTAX_V1: "UTF8_TSV_SYNTAX_V1";
            UTF8_JSONL_SYNTAX_V1: "UTF8_JSONL_SYNTAX_V1";
            RIFF_INTEGER_PCM_WAVE_V1: "RIFF_INTEGER_PCM_WAVE_V1";
            PNG_STATIC_8BIT_V1: "PNG_STATIC_8BIT_V1";
            ZIP32_CONTAINER_V1: "ZIP32_CONTAINER_V1";
        }>;
        maximumObjectBytes: z.ZodString;
        choices: z.ZodTuple<[z.ZodLiteral<"SAMPLE_ONLY">, z.ZodLiteral<"FULL_ONLY">, z.ZodLiteral<"FULL_AND_SAMPLE">], null>;
        extensions: z.ZodArray<z.ZodString>;
        mimeTypes: z.ZodArray<z.ZodString>;
    }, z.core.$strict>>;
    transport: z.ZodNullable<z.ZodObject<{
        kind: z.ZodLiteral<"BOUNDED_PARTS_V1">;
        partBytes: z.ZodNumber;
        maximumParts: z.ZodLiteral<10000>;
        mediaType: z.ZodLiteral<"application/octet-stream">;
        partPathTemplate: z.ZodLiteral<"/api/v2/supplier/dataset-drafts/{draftId}/uploads/{attemptId}/parts/{partNumber}">;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare const DatasetUploadAttemptIdParamsSchema: z.ZodObject<{
    draftId: z.ZodString;
    attemptId: z.ZodString;
}, z.core.$strict>;
export declare const DatasetUploadsPageQuerySchema: z.ZodObject<{
    component: z.ZodOptional<z.ZodEnum<{
        FULL: "FULL";
        SAMPLE: "SAMPLE";
    }>>;
    afterId: z.ZodOptional<z.ZodString>;
    limit: z.ZodDefault<z.ZodUnion<readonly [z.ZodNumber, z.ZodPipe<z.ZodPipe<z.ZodString, z.ZodTransform<number, string>>, z.ZodNumber>]>>;
}, z.core.$strict>;
export declare const DatasetUploadsPageResponseSchema: z.ZodObject<{
    preparationId: z.ZodString;
    items: z.ZodArray<z.ZodObject<{
        component: z.ZodEnum<{
            FULL: "FULL";
            SAMPLE: "SAMPLE";
        }>;
        role: z.ZodEnum<{
            PRIMARY: "PRIMARY";
            TRANSCRIPT: "TRANSCRIPT";
            ANNOTATION: "ANNOTATION";
            SENSOR: "SENSOR";
            CALIBRATION: "CALIBRATION";
            DOCUMENTATION: "DOCUMENTATION";
        }>;
        inspectionProfile: z.ZodNonOptional<z.ZodOptional<z.ZodUnion<readonly [z.ZodDiscriminatedUnion<[z.ZodObject<{
            profileId: z.ZodEnum<{
                UTF8_CSV_SYNTAX_V1: "UTF8_CSV_SYNTAX_V1";
                UTF8_TSV_SYNTAX_V1: "UTF8_TSV_SYNTAX_V1";
            }>;
            header: z.ZodEnum<{
                PRESENT: "PRESENT";
                ABSENT: "ABSENT";
            }>;
        }, z.core.$strict>, z.ZodObject<{
            profileId: z.ZodLiteral<"UTF8_JSONL_SYNTAX_V1">;
            recordKind: z.ZodEnum<{
                OBJECT: "OBJECT";
                OBJECT_OR_ARRAY: "OBJECT_OR_ARRAY";
            }>;
        }, z.core.$strict>, z.ZodObject<{
            profileId: z.ZodLiteral<"RIFF_INTEGER_PCM_WAVE_V1">;
        }, z.core.$strict>, z.ZodObject<{
            profileId: z.ZodLiteral<"PNG_STATIC_8BIT_V1">;
        }, z.core.$strict>, z.ZodObject<{
            profileId: z.ZodLiteral<"JPEG_BASELINE_STRUCTURE_V1">;
        }, z.core.$strict>], "profileId">, z.ZodObject<{
            profileId: z.ZodLiteral<"ZIP32_CONTAINER_V1">;
            leafProfiles: z.ZodArray<z.ZodObject<{
                locator: z.ZodDiscriminatedUnion<[z.ZodObject<{
                    kind: z.ZodLiteral<"ARCHIVE_ENTRY">;
                    path: z.ZodString;
                }, z.core.$strict>, z.ZodObject<{
                    kind: z.ZodLiteral<"WORKBOOK_SHEET">;
                    sheetName: z.ZodString;
                }, z.core.$strict>], "kind"> & z.ZodType<{
                    kind: "ARCHIVE_ENTRY";
                    path: string;
                }, {
                    kind: "ARCHIVE_ENTRY";
                    path: string;
                } | {
                    kind: "WORKBOOK_SHEET";
                    sheetName: string;
                }, z.core.$ZodTypeInternals<{
                    kind: "ARCHIVE_ENTRY";
                    path: string;
                }, {
                    kind: "ARCHIVE_ENTRY";
                    path: string;
                } | {
                    kind: "WORKBOOK_SHEET";
                    sheetName: string;
                }>>;
                profile: z.ZodDiscriminatedUnion<[z.ZodObject<{
                    profileId: z.ZodEnum<{
                        UTF8_CSV_SYNTAX_V1: "UTF8_CSV_SYNTAX_V1";
                        UTF8_TSV_SYNTAX_V1: "UTF8_TSV_SYNTAX_V1";
                    }>;
                    header: z.ZodEnum<{
                        PRESENT: "PRESENT";
                        ABSENT: "ABSENT";
                    }>;
                }, z.core.$strict>, z.ZodObject<{
                    profileId: z.ZodLiteral<"UTF8_JSONL_SYNTAX_V1">;
                    recordKind: z.ZodEnum<{
                        OBJECT: "OBJECT";
                        OBJECT_OR_ARRAY: "OBJECT_OR_ARRAY";
                    }>;
                }, z.core.$strict>, z.ZodObject<{
                    profileId: z.ZodLiteral<"RIFF_INTEGER_PCM_WAVE_V1">;
                }, z.core.$strict>, z.ZodObject<{
                    profileId: z.ZodLiteral<"PNG_STATIC_8BIT_V1">;
                }, z.core.$strict>, z.ZodObject<{
                    profileId: z.ZodLiteral<"JPEG_BASELINE_STRUCTURE_V1">;
                }, z.core.$strict>], "profileId">;
            }, z.core.$strict>>;
            entryDefaults: z.ZodOptional<z.ZodArray<z.ZodObject<{
                extension: z.ZodString;
                profile: z.ZodDiscriminatedUnion<[z.ZodObject<{
                    profileId: z.ZodEnum<{
                        UTF8_CSV_SYNTAX_V1: "UTF8_CSV_SYNTAX_V1";
                        UTF8_TSV_SYNTAX_V1: "UTF8_TSV_SYNTAX_V1";
                    }>;
                    header: z.ZodEnum<{
                        PRESENT: "PRESENT";
                        ABSENT: "ABSENT";
                    }>;
                }, z.core.$strict>, z.ZodObject<{
                    profileId: z.ZodLiteral<"UTF8_JSONL_SYNTAX_V1">;
                    recordKind: z.ZodEnum<{
                        OBJECT: "OBJECT";
                        OBJECT_OR_ARRAY: "OBJECT_OR_ARRAY";
                    }>;
                }, z.core.$strict>, z.ZodObject<{
                    profileId: z.ZodLiteral<"RIFF_INTEGER_PCM_WAVE_V1">;
                }, z.core.$strict>, z.ZodObject<{
                    profileId: z.ZodLiteral<"PNG_STATIC_8BIT_V1">;
                }, z.core.$strict>, z.ZodObject<{
                    profileId: z.ZodLiteral<"JPEG_BASELINE_STRUCTURE_V1">;
                }, z.core.$strict>], "profileId">;
            }, z.core.$strict>>>;
        }, z.core.$strict>]>>>;
        originalName: z.ZodString;
        expectedBytes: z.ZodString;
        id: z.ZodString;
        rootId: z.ZodString;
        contentId: z.ZodString;
        revision: z.ZodNumber;
        retainedBytes: z.ZodString;
        reservedBytes: z.ZodString;
        partBytes: z.ZodNumber;
        totalParts: z.ZodNumber;
        state: z.ZodEnum<{
            ADMITTED: "ADMITTED";
            RECEIVING: "RECEIVING";
            FINALIZING: "FINALIZING";
            RECEIVED: "RECEIVED";
            CHECKING: "CHECKING";
            ACCEPTED: "ACCEPTED";
            REJECTED: "REJECTED";
            CANCEL_REQUESTED: "CANCEL_REQUESTED";
            RECONCILIATION_REQUIRED: "RECONCILIATION_REQUIRED";
            CLOSED: "CLOSED";
        }>;
        recoveryEpoch: z.ZodNonOptional<z.ZodOptional<z.ZodNumber>>;
        expiresAt: z.ZodString;
        eligibility: z.ZodEnum<{
            ACCEPTED: "ACCEPTED";
            NOT_ACCEPTED: "NOT_ACCEPTED";
        }>;
        uploadObjectId: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    }, z.core.$strict>>;
    nextCursor: z.ZodNullable<z.ZodObject<{
        afterId: z.ZodString;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare const DatasetUploadPartsPageQuerySchema: z.ZodObject<{
    expectedAttemptRevision: z.ZodUnion<readonly [z.ZodNumber, z.ZodPipe<z.ZodPipe<z.ZodString, z.ZodTransform<number, string>>, z.ZodNumber>]>;
    expectedRecoveryEpoch: z.ZodUnion<readonly [z.ZodNumber, z.ZodPipe<z.ZodPipe<z.ZodString, z.ZodTransform<number, string>>, z.ZodNumber>]>;
    afterPartNumber: z.ZodOptional<z.ZodUnion<readonly [z.ZodNumber, z.ZodPipe<z.ZodPipe<z.ZodString, z.ZodTransform<number, string>>, z.ZodNumber>]>>;
    limit: z.ZodDefault<z.ZodUnion<readonly [z.ZodNumber, z.ZodPipe<z.ZodPipe<z.ZodString, z.ZodTransform<number, string>>, z.ZodNumber>]>>;
}, z.core.$strict>;
export declare const DatasetUploadPartStatusSchema: z.ZodObject<{
    partNumber: z.ZodNumber;
    expectedBytes: z.ZodNumber;
    measuredBytes: z.ZodNullable<z.ZodNumber>;
    state: z.ZodEnum<{
        RECEIVED: "RECEIVED";
        PENDING: "PENDING";
        CLAIMED: "CLAIMED";
        UNCERTAIN: "UNCERTAIN";
    }>;
    receivedAt: z.ZodNullable<z.ZodString>;
    checksumSha256: z.ZodNullable<z.ZodString>;
}, z.core.$strict>;
export declare const DatasetUploadPartsPageResponseSchema: z.ZodObject<{
    preparationId: z.ZodString;
    attemptId: z.ZodString;
    attemptRevision: z.ZodNumber;
    recoveryEpoch: z.ZodNumber;
    totalParts: z.ZodNumber;
    items: z.ZodArray<z.ZodObject<{
        partNumber: z.ZodNumber;
        expectedBytes: z.ZodNumber;
        measuredBytes: z.ZodNullable<z.ZodNumber>;
        state: z.ZodEnum<{
            RECEIVED: "RECEIVED";
            PENDING: "PENDING";
            CLAIMED: "CLAIMED";
            UNCERTAIN: "UNCERTAIN";
        }>;
        receivedAt: z.ZodNullable<z.ZodString>;
        checksumSha256: z.ZodNullable<z.ZodString>;
    }, z.core.$strict>>;
    nextCursor: z.ZodNullable<z.ZodObject<{
        afterPartNumber: z.ZodNumber;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare const DatasetUploadPartParamsSchema: z.ZodObject<{
    draftId: z.ZodString;
    attemptId: z.ZodString;
    partNumber: z.ZodUnion<readonly [z.ZodNumber, z.ZodPipe<z.ZodPipe<z.ZodString, z.ZodTransform<number, string>>, z.ZodNumber>]>;
}, z.core.$strict>;
export declare const DatasetUploadPartQuerySchema: z.ZodObject<{
    requestId: z.ZodPipe<z.ZodString, z.ZodTransform<string, string>>;
    expectedPreparationGeneration: z.ZodUnion<readonly [z.ZodNumber, z.ZodPipe<z.ZodPipe<z.ZodString, z.ZodTransform<number, string>>, z.ZodNumber>]>;
    expectedContentId: z.ZodString;
    expectedContentGeneration: z.ZodUnion<readonly [z.ZodNumber, z.ZodPipe<z.ZodPipe<z.ZodString, z.ZodTransform<number, string>>, z.ZodNumber>]>;
}, z.core.$strict>;
export type DatasetUploadAdmissionBody = z.infer<typeof DatasetUploadAdmissionBodySchema>;
export type DatasetUploadActionBody = z.infer<typeof DatasetUploadActionBodySchema>;
export type DatasetUploadCancelBody = z.infer<typeof DatasetUploadCancelBodySchema>;
export type DatasetUploadAttemptResponse = z.infer<typeof DatasetUploadAttemptResponseSchema>;
export type DatasetUploadAttemptStatusResponse = z.infer<typeof DatasetUploadAttemptStatusResponseSchema>;
export type DatasetIntakeConfigQuery = z.infer<typeof DatasetIntakeConfigQuerySchema>;
export type DatasetIntakeConfigResponse = z.infer<typeof DatasetIntakeConfigResponseSchema>;
export type DatasetIntakeCapability = z.infer<typeof DatasetIntakeCapabilitySchema>;
export type DatasetIntakeTransport = z.infer<typeof DatasetIntakeTransportSchema>;
export type DatasetUploadsPageQuery = z.infer<typeof DatasetUploadsPageQuerySchema>;
export type DatasetUploadsPageResponse = z.infer<typeof DatasetUploadsPageResponseSchema>;
export type DatasetUploadPartsPageQuery = z.infer<typeof DatasetUploadPartsPageQuerySchema>;
export type DatasetUploadPartsPageResponse = z.infer<typeof DatasetUploadPartsPageResponseSchema>;
export type DatasetUploadPartParams = z.infer<typeof DatasetUploadPartParamsSchema>;
export type DatasetUploadPartQuery = z.infer<typeof DatasetUploadPartQuerySchema>;
//# sourceMappingURL=intake.schema.d.ts.map