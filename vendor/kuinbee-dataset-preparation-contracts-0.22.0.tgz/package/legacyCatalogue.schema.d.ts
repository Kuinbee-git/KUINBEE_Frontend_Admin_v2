import { z } from "zod";
export declare const MarketplaceDatasetStatusSchema: z.ZodLiteral<"PUBLISHED">;
export declare const MarketplaceDatasetDiscountDtoSchema: z.ZodObject<{
    proposalId: z.ZodString;
    type: z.ZodEnum<{
        PERCENTAGE: "PERCENTAGE";
        FIXED_AMOUNT: "FIXED_AMOUNT";
    }>;
    value: z.ZodString;
    amountOff: z.ZodString;
    startsAt: z.ZodString;
    endsAt: z.ZodString;
}, z.core.$strip>;
export type MarketplaceDatasetDiscountDto = z.infer<typeof MarketplaceDatasetDiscountDtoSchema>;
export declare const MarketplaceDatasetAccessFlowSchema: z.ZodEnum<{
    FREE_CLAIM: "FREE_CLAIM";
    PAID_CHECKOUT: "PAID_CHECKOUT";
}>;
export type MarketplaceDatasetAccessFlow = z.infer<typeof MarketplaceDatasetAccessFlowSchema>;
export declare const MarketplaceDatasetCommercialFlowSchema: z.ZodEnum<{
    NONE: "NONE";
    DIRECT_PLATFORM_PURCHASE: "DIRECT_PLATFORM_PURCHASE";
    INQUIRY_FOR_FULL_DATASET: "INQUIRY_FOR_FULL_DATASET";
}>;
export type MarketplaceDatasetCommercialFlow = z.infer<typeof MarketplaceDatasetCommercialFlowSchema>;
export declare const MarketplaceDatasetPriceSurfaceDtoSchema: z.ZodObject<{
    surface: z.ZodNullable<z.ZodEnum<{
        DATASET_PRICING: "DATASET_PRICING";
        SAMPLE_ACTUAL_PRICE: "SAMPLE_ACTUAL_PRICE";
    }>>;
    baseAmount: z.ZodNullable<z.ZodString>;
    finalAmount: z.ZodNullable<z.ZodString>;
    currency: z.ZodNullable<z.ZodString>;
    discount: z.ZodNullable<z.ZodObject<{
        proposalId: z.ZodString;
        type: z.ZodEnum<{
            PERCENTAGE: "PERCENTAGE";
            FIXED_AMOUNT: "FIXED_AMOUNT";
        }>;
        value: z.ZodString;
        amountOff: z.ZodString;
        startsAt: z.ZodString;
        endsAt: z.ZodString;
    }, z.core.$strip>>;
    payable: z.ZodBoolean;
    visible: z.ZodBoolean;
}, z.core.$strip>;
export type MarketplaceDatasetPriceSurfaceDto = z.infer<typeof MarketplaceDatasetPriceSurfaceDtoSchema>;
export declare const MarketplaceOwnerDtoSchema: z.ZodObject<{
    id: z.ZodString;
    type: z.ZodEnum<{
        platform: "platform";
        supplier: "supplier";
    }>;
    name: z.ZodString;
    logoUrl: z.ZodOptional<z.ZodNullable<z.ZodString>>;
}, z.core.$strip>;
export type MarketplaceOwnerDto = z.infer<typeof MarketplaceOwnerDtoSchema>;
export declare const MarketplaceCategoryLiteDtoSchema: z.ZodObject<{
    name: z.ZodString;
}, z.core.$strip>;
export type MarketplaceCategoryLiteDto = z.infer<typeof MarketplaceCategoryLiteDtoSchema>;
export declare const MarketplaceLocationLiteDtoSchema: z.ZodObject<{
    country: z.ZodString;
    state: z.ZodNullable<z.ZodString>;
    city: z.ZodNullable<z.ZodString>;
}, z.core.$strip>;
export type MarketplaceLocationLiteDto = z.infer<typeof MarketplaceLocationLiteDtoSchema>;
export declare const MarketplaceDataFormatInfoLiteDtoSchema: z.ZodObject<{
    fileFormat: z.ZodNullable<z.ZodString>;
    rows: z.ZodNullable<z.ZodNumber>;
    cols: z.ZodNullable<z.ZodNumber>;
    fileSize: z.ZodNullable<z.ZodString>;
}, z.core.$strip>;
export type MarketplaceDataFormatInfoLiteDto = z.infer<typeof MarketplaceDataFormatInfoLiteDtoSchema>;
export declare const MarketplaceAboutDatasetInfoDtoSchema: z.ZodObject<{
    overview: z.ZodNullable<z.ZodString>;
    description: z.ZodNullable<z.ZodString>;
    dataQuality: z.ZodNullable<z.ZodString>;
    useCases: z.ZodNullable<z.ZodString>;
    limitations: z.ZodNullable<z.ZodString>;
    methodology: z.ZodNullable<z.ZodString>;
    updatedAt: z.ZodNullable<z.ZodString>;
}, z.core.$strip>;
export type MarketplaceAboutDatasetInfoDto = z.infer<typeof MarketplaceAboutDatasetInfoDtoSchema>;
export declare const MarketplaceDataFormatInfoDtoSchema: z.ZodObject<{
    fileFormat: z.ZodNullable<z.ZodString>;
    rows: z.ZodNullable<z.ZodNumber>;
    cols: z.ZodNullable<z.ZodNumber>;
    fileSize: z.ZodNullable<z.ZodString>;
    compressionType: z.ZodNullable<z.ZodString>;
    encoding: z.ZodNullable<z.ZodEnum<{
        "UTF-8": "UTF-8";
        "UTF-16": "UTF-16";
        "UTF-16LE": "UTF-16LE";
        "UTF-16BE": "UTF-16BE";
        "UTF-32": "UTF-32";
        ASCII: "ASCII";
        "ISO-8859-1": "ISO-8859-1";
        "WINDOWS-1252": "WINDOWS-1252";
        SHIFT_JIS: "SHIFT_JIS";
        GB18030: "GB18030";
    }>>;
    updatedAt: z.ZodNullable<z.ZodString>;
}, z.core.$strip>;
export type MarketplaceDataFormatInfoDto = z.infer<typeof MarketplaceDataFormatInfoDtoSchema>;
export declare const MarketplaceFeatureDtoSchema: z.ZodObject<{
    id: z.ZodString;
    name: z.ZodString;
    dataType: z.ZodString;
    description: z.ZodNullable<z.ZodString>;
    isNullable: z.ZodBoolean;
}, z.core.$strip>;
export type MarketplaceFeatureDto = z.infer<typeof MarketplaceFeatureDtoSchema>;
export declare const MarketplaceSourceDtoSchema: z.ZodObject<{
    id: z.ZodString;
    name: z.ZodString;
    description: z.ZodNullable<z.ZodString>;
    websiteUrl: z.ZodNullable<z.ZodString>;
    isVerified: z.ZodBoolean;
}, z.core.$strip>;
export type MarketplaceSourceDto = z.infer<typeof MarketplaceSourceDtoSchema>;
export declare const MarketplaceLocationInfoDtoSchema: z.ZodObject<{
    region: z.ZodNullable<z.ZodString>;
    country: z.ZodString;
    state: z.ZodNullable<z.ZodString>;
    city: z.ZodNullable<z.ZodString>;
    coordinates: z.ZodNullable<z.ZodString>;
    coverage: z.ZodNullable<z.ZodString>;
}, z.core.$strip>;
export type MarketplaceLocationInfoDto = z.infer<typeof MarketplaceLocationInfoDtoSchema>;
export declare const MarketplaceDatasetListItemDtoSchema: z.ZodObject<{
    id: z.ZodString;
    datasetUniqueId: z.ZodString;
    title: z.ZodString;
    status: z.ZodLiteral<"PUBLISHED">;
    license: z.ZodString;
    owner: z.ZodObject<{
        id: z.ZodString;
        type: z.ZodEnum<{
            platform: "platform";
            supplier: "supplier";
        }>;
        name: z.ZodString;
        logoUrl: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    }, z.core.$strip>;
    category: z.ZodObject<{
        name: z.ZodString;
    }, z.core.$strip>;
    location: z.ZodNullable<z.ZodObject<{
        country: z.ZodString;
        state: z.ZodNullable<z.ZodString>;
        city: z.ZodNullable<z.ZodString>;
    }, z.core.$strip>>;
    dataFormatInfo: z.ZodObject<{
        fileFormat: z.ZodNullable<z.ZodString>;
        rows: z.ZodNullable<z.ZodNumber>;
        cols: z.ZodNullable<z.ZodNumber>;
        fileSize: z.ZodNullable<z.ZodString>;
    }, z.core.$strip>;
    tags: z.ZodArray<z.ZodString>;
    isPaid: z.ZodBoolean;
    price: z.ZodNullable<z.ZodString>;
    currency: z.ZodEnum<{
        INR: "INR";
        USD: "USD";
        EUR: "EUR";
        GBP: "GBP";
    }>;
    accessFlow: z.ZodEnum<{
        FREE_CLAIM: "FREE_CLAIM";
        PAID_CHECKOUT: "PAID_CHECKOUT";
    }>;
    commercialFlow: z.ZodEnum<{
        NONE: "NONE";
        DIRECT_PLATFORM_PURCHASE: "DIRECT_PLATFORM_PURCHASE";
        INQUIRY_FOR_FULL_DATASET: "INQUIRY_FOR_FULL_DATASET";
    }>;
    accessPrice: z.ZodObject<{
        surface: z.ZodNullable<z.ZodEnum<{
            DATASET_PRICING: "DATASET_PRICING";
            SAMPLE_ACTUAL_PRICE: "SAMPLE_ACTUAL_PRICE";
        }>>;
        baseAmount: z.ZodNullable<z.ZodString>;
        finalAmount: z.ZodNullable<z.ZodString>;
        currency: z.ZodNullable<z.ZodString>;
        discount: z.ZodNullable<z.ZodObject<{
            proposalId: z.ZodString;
            type: z.ZodEnum<{
                PERCENTAGE: "PERCENTAGE";
                FIXED_AMOUNT: "FIXED_AMOUNT";
            }>;
            value: z.ZodString;
            amountOff: z.ZodString;
            startsAt: z.ZodString;
            endsAt: z.ZodString;
        }, z.core.$strip>>;
        payable: z.ZodBoolean;
        visible: z.ZodBoolean;
    }, z.core.$strip>;
    commercialPrice: z.ZodObject<{
        surface: z.ZodNullable<z.ZodEnum<{
            DATASET_PRICING: "DATASET_PRICING";
            SAMPLE_ACTUAL_PRICE: "SAMPLE_ACTUAL_PRICE";
        }>>;
        baseAmount: z.ZodNullable<z.ZodString>;
        finalAmount: z.ZodNullable<z.ZodString>;
        currency: z.ZodNullable<z.ZodString>;
        discount: z.ZodNullable<z.ZodObject<{
            proposalId: z.ZodString;
            type: z.ZodEnum<{
                PERCENTAGE: "PERCENTAGE";
                FIXED_AMOUNT: "FIXED_AMOUNT";
            }>;
            value: z.ZodString;
            amountOff: z.ZodString;
            startsAt: z.ZodString;
            endsAt: z.ZodString;
        }, z.core.$strip>>;
        payable: z.ZodBoolean;
        visible: z.ZodBoolean;
    }, z.core.$strip>;
    viewCount: z.ZodNumber;
    downloadCount: z.ZodNumber;
    reviewCount: z.ZodNumber;
    rating: z.ZodNullable<z.ZodString>;
    kdtsScore: z.ZodNullable<z.ZodString>;
    searchScore: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
    isSample: z.ZodBoolean;
    sampleFileAvailable: z.ZodBoolean;
    sampleNotes: z.ZodOptional<z.ZodNullable<z.ZodObject<{
        whySample: z.ZodString;
        actualDataSize: z.ZodString;
        completeness: z.ZodOptional<z.ZodString>;
        deliveryMechanism: z.ZodEnum<{
            OTHER: "OTHER";
            API: "API";
            FILE: "FILE";
        }>;
        deliveryMechanismNotes: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>>>;
    actualPrice: z.ZodNullable<z.ZodString>;
    actualPriceCurrency: z.ZodNullable<z.ZodString>;
    buyInPartsAvailable: z.ZodBoolean;
    createdAt: z.ZodString;
    updatedAt: z.ZodString;
}, z.core.$strip>;
export type MarketplaceDatasetListItemDto = z.infer<typeof MarketplaceDatasetListItemDtoSchema>;
export declare const MarketplaceDatasetDetailsDtoSchema: z.ZodObject<{
    dataset: z.ZodObject<{
        id: z.ZodString;
        datasetUniqueId: z.ZodString;
        title: z.ZodString;
        status: z.ZodLiteral<"PUBLISHED">;
        visibility: z.ZodEnum<{
            PUBLIC: "PUBLIC";
            PRIVATE: "PRIVATE";
            UNLISTED: "UNLISTED";
        }>;
        superType: z.ZodString;
        isPaid: z.ZodBoolean;
        price: z.ZodNullable<z.ZodString>;
        currency: z.ZodEnum<{
            INR: "INR";
            USD: "USD";
            EUR: "EUR";
            GBP: "GBP";
        }>;
        accessFlow: z.ZodEnum<{
            FREE_CLAIM: "FREE_CLAIM";
            PAID_CHECKOUT: "PAID_CHECKOUT";
        }>;
        commercialFlow: z.ZodEnum<{
            NONE: "NONE";
            DIRECT_PLATFORM_PURCHASE: "DIRECT_PLATFORM_PURCHASE";
            INQUIRY_FOR_FULL_DATASET: "INQUIRY_FOR_FULL_DATASET";
        }>;
        accessPrice: z.ZodObject<{
            surface: z.ZodNullable<z.ZodEnum<{
                DATASET_PRICING: "DATASET_PRICING";
                SAMPLE_ACTUAL_PRICE: "SAMPLE_ACTUAL_PRICE";
            }>>;
            baseAmount: z.ZodNullable<z.ZodString>;
            finalAmount: z.ZodNullable<z.ZodString>;
            currency: z.ZodNullable<z.ZodString>;
            discount: z.ZodNullable<z.ZodObject<{
                proposalId: z.ZodString;
                type: z.ZodEnum<{
                    PERCENTAGE: "PERCENTAGE";
                    FIXED_AMOUNT: "FIXED_AMOUNT";
                }>;
                value: z.ZodString;
                amountOff: z.ZodString;
                startsAt: z.ZodString;
                endsAt: z.ZodString;
            }, z.core.$strip>>;
            payable: z.ZodBoolean;
            visible: z.ZodBoolean;
        }, z.core.$strip>;
        commercialPrice: z.ZodObject<{
            surface: z.ZodNullable<z.ZodEnum<{
                DATASET_PRICING: "DATASET_PRICING";
                SAMPLE_ACTUAL_PRICE: "SAMPLE_ACTUAL_PRICE";
            }>>;
            baseAmount: z.ZodNullable<z.ZodString>;
            finalAmount: z.ZodNullable<z.ZodString>;
            currency: z.ZodNullable<z.ZodString>;
            discount: z.ZodNullable<z.ZodObject<{
                proposalId: z.ZodString;
                type: z.ZodEnum<{
                    PERCENTAGE: "PERCENTAGE";
                    FIXED_AMOUNT: "FIXED_AMOUNT";
                }>;
                value: z.ZodString;
                amountOff: z.ZodString;
                startsAt: z.ZodString;
                endsAt: z.ZodString;
            }, z.core.$strip>>;
            payable: z.ZodBoolean;
            visible: z.ZodBoolean;
        }, z.core.$strip>;
        license: z.ZodString;
        downloadCount: z.ZodNumber;
        viewCount: z.ZodNumber;
        rating: z.ZodNullable<z.ZodString>;
        createdAt: z.ZodString;
        updatedAt: z.ZodString;
        description: z.ZodNullable<z.ZodString>;
        isSample: z.ZodBoolean;
        sampleFileAvailable: z.ZodBoolean;
        sampleNotes: z.ZodNullable<z.ZodObject<{
            whySample: z.ZodString;
            actualDataSize: z.ZodString;
            completeness: z.ZodOptional<z.ZodString>;
            deliveryMechanism: z.ZodEnum<{
                OTHER: "OTHER";
                API: "API";
                FILE: "FILE";
            }>;
            deliveryMechanismNotes: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>>;
        actualPrice: z.ZodNullable<z.ZodString>;
        actualPriceCurrency: z.ZodNullable<z.ZodString>;
        isNegotiable: z.ZodNullable<z.ZodBoolean>;
        buyInPartsAvailable: z.ZodBoolean;
    }, z.core.$strip>;
    primaryCategory: z.ZodObject<{
        name: z.ZodString;
    }, z.core.$strip>;
    secondaryCategories: z.ZodArray<z.ZodObject<{
        name: z.ZodString;
    }, z.core.$strip>>;
    aboutDatasetInfo: z.ZodObject<{
        overview: z.ZodNullable<z.ZodString>;
        description: z.ZodNullable<z.ZodString>;
        dataQuality: z.ZodNullable<z.ZodString>;
        useCases: z.ZodNullable<z.ZodString>;
        limitations: z.ZodNullable<z.ZodString>;
        methodology: z.ZodNullable<z.ZodString>;
        updatedAt: z.ZodNullable<z.ZodString>;
    }, z.core.$strip>;
    dataFormatInfo: z.ZodObject<{
        fileFormat: z.ZodNullable<z.ZodString>;
        rows: z.ZodNullable<z.ZodNumber>;
        cols: z.ZodNullable<z.ZodNumber>;
        fileSize: z.ZodNullable<z.ZodString>;
        compressionType: z.ZodNullable<z.ZodString>;
        encoding: z.ZodNullable<z.ZodEnum<{
            "UTF-8": "UTF-8";
            "UTF-16": "UTF-16";
            "UTF-16LE": "UTF-16LE";
            "UTF-16BE": "UTF-16BE";
            "UTF-32": "UTF-32";
            ASCII: "ASCII";
            "ISO-8859-1": "ISO-8859-1";
            "WINDOWS-1252": "WINDOWS-1252";
            SHIFT_JIS: "SHIFT_JIS";
            GB18030: "GB18030";
        }>>;
        updatedAt: z.ZodNullable<z.ZodString>;
    }, z.core.$strip>;
    features: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        name: z.ZodString;
        dataType: z.ZodString;
        description: z.ZodNullable<z.ZodString>;
        isNullable: z.ZodBoolean;
    }, z.core.$strip>>;
    source: z.ZodObject<{
        id: z.ZodString;
        name: z.ZodString;
        description: z.ZodNullable<z.ZodString>;
        websiteUrl: z.ZodNullable<z.ZodString>;
        isVerified: z.ZodBoolean;
    }, z.core.$strip>;
    locationInfo: z.ZodNullable<z.ZodObject<{
        region: z.ZodNullable<z.ZodString>;
        country: z.ZodString;
        state: z.ZodNullable<z.ZodString>;
        city: z.ZodNullable<z.ZodString>;
        coordinates: z.ZodNullable<z.ZodString>;
        coverage: z.ZodNullable<z.ZodString>;
    }, z.core.$strip>>;
    tags: z.ZodArray<z.ZodString>;
}, z.core.$strip>;
export type MarketplaceDatasetDetailsDto = z.infer<typeof MarketplaceDatasetDetailsDtoSchema>;
export declare const MarketplaceCategoryDtoSchema: z.ZodObject<{
    id: z.ZodString;
    name: z.ZodString;
    datasetCount: z.ZodNumber;
}, z.core.$strip>;
export type MarketplaceCategoryDto = z.infer<typeof MarketplaceCategoryDtoSchema>;
export declare const MarketplaceReviewDtoSchema: z.ZodObject<{
    id: z.ZodString;
    rating: z.ZodNumber;
    comment: z.ZodNullable<z.ZodString>;
    createdAt: z.ZodString;
    updatedAt: z.ZodOptional<z.ZodString>;
}, z.core.$strip>;
export type MarketplaceReviewDto = z.infer<typeof MarketplaceReviewDtoSchema>;
export declare const MarketplaceAnswerDtoSchema: z.ZodObject<{
    id: z.ZodString;
    answer: z.ZodString;
    createdAt: z.ZodString;
}, z.core.$strip>;
export type MarketplaceAnswerDto = z.infer<typeof MarketplaceAnswerDtoSchema>;
export declare const MarketplaceQuestionDtoSchema: z.ZodObject<{
    id: z.ZodString;
    question: z.ZodString;
    answers: z.ZodDefault<z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        answer: z.ZodString;
        createdAt: z.ZodString;
    }, z.core.$strip>>>;
    createdAt: z.ZodString;
}, z.core.$strip>;
export type MarketplaceQuestionDto = z.infer<typeof MarketplaceQuestionDtoSchema>;
//# sourceMappingURL=legacyCatalogue.schema.d.ts.map