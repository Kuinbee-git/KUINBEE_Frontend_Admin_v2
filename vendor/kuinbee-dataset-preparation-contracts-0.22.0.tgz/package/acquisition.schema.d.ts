import { z } from "zod";
export declare const DatasetAcquisitionOfferQuerySchema: z.ZodObject<{}, z.core.$strict>;
export declare const DatasetAcquisitionTargetSchema: z.ZodObject<{
    datasetId: z.ZodString;
    contentId: z.ZodString;
    component: z.ZodLiteral<"FULL">;
    publicationId: z.ZodString;
    pricingVersionId: z.ZodString;
    pricingRevision: z.ZodNumber;
    amount: z.ZodString;
    currency: z.ZodEnum<{
        INR: "INR";
        USD: "USD";
        EUR: "EUR";
        GBP: "GBP";
    }>;
}, z.core.$strict>;
export declare const DatasetAcquisitionOfferResponseSchema: z.ZodObject<{
    target: z.ZodObject<{
        datasetId: z.ZodString;
        contentId: z.ZodString;
        component: z.ZodLiteral<"FULL">;
        publicationId: z.ZodString;
        pricingVersionId: z.ZodString;
        pricingRevision: z.ZodNumber;
        amount: z.ZodString;
        currency: z.ZodEnum<{
            INR: "INR";
            USD: "USD";
            EUR: "EUR";
            GBP: "GBP";
        }>;
    }, z.core.$strict>;
    accessFlow: z.ZodEnum<{
        FREE_CLAIM: "FREE_CLAIM";
        PAID_CHECKOUT: "PAID_CHECKOUT";
    }>;
    baseAmount: z.ZodString;
    discountProposalId: z.ZodNullable<z.ZodString>;
    discountAmount: z.ZodNullable<z.ZodString>;
}, z.core.$strict>;
export declare const DatasetContentFreeClaimBodySchema: z.ZodObject<{
    expectedTarget: z.ZodObject<{
        datasetId: z.ZodString;
        contentId: z.ZodString;
        component: z.ZodLiteral<"FULL">;
        publicationId: z.ZodString;
        pricingVersionId: z.ZodString;
        pricingRevision: z.ZodNumber;
        amount: z.ZodString;
        currency: z.ZodEnum<{
            INR: "INR";
            USD: "USD";
            EUR: "EUR";
            GBP: "GBP";
        }>;
    }, z.core.$strict>;
}, z.core.$strict>;
export declare const DatasetContentFreeClaimResponseSchema: z.ZodObject<{
    success: z.ZodLiteral<true>;
    grantId: z.ZodString;
    material: z.ZodObject<{
        datasetId: z.ZodString;
        contentId: z.ZodString;
        component: z.ZodLiteral<"FULL">;
    }, z.core.$strict>;
}, z.core.$strict>;
export type DatasetAcquisitionTarget = z.infer<typeof DatasetAcquisitionTargetSchema>;
export type DatasetContentFreeClaimBody = z.infer<typeof DatasetContentFreeClaimBodySchema>;
//# sourceMappingURL=acquisition.schema.d.ts.map