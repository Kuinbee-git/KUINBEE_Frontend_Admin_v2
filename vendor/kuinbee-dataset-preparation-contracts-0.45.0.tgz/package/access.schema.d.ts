import { z } from "zod";
export declare const DatasetFileAccessScopeSchema: z.ZodEnum<{
    PUBLISHED: "PUBLISHED";
    WORKING: "WORKING";
    REVIEWED: "REVIEWED";
    EDIT_BASE: "EDIT_BASE";
    GRANTED: "GRANTED";
}>;
export declare const DatasetFileAccessSelectionSchema: z.ZodObject<{
    scope: z.ZodEnum<{
        PUBLISHED: "PUBLISHED";
        WORKING: "WORKING";
        REVIEWED: "REVIEWED";
        EDIT_BASE: "EDIT_BASE";
        GRANTED: "GRANTED";
    }>;
    component: z.ZodEnum<{
        SAMPLE: "SAMPLE";
        FULL: "FULL";
    }>;
    editOperation: z.ZodOptional<z.ZodEnum<{
        METADATA: "METADATA";
        PRICING: "PRICING";
        MATERIALS: "MATERIALS";
    }>>;
}, z.core.$strict>;
export declare const DatasetFileAccessContextSchema: z.ZodObject<{
    datasetId: z.ZodString;
    scope: z.ZodEnum<{
        PUBLISHED: "PUBLISHED";
        WORKING: "WORKING";
        REVIEWED: "REVIEWED";
        EDIT_BASE: "EDIT_BASE";
        GRANTED: "GRANTED";
    }>;
    component: z.ZodEnum<{
        SAMPLE: "SAMPLE";
        FULL: "FULL";
    }>;
    editOperation: z.ZodNullable<z.ZodEnum<{
        METADATA: "METADATA";
        PRICING: "PRICING";
        MATERIALS: "MATERIALS";
    }>>;
    contentId: z.ZodString;
    contentGeneration: z.ZodNumber;
    workflowRevision: z.ZodNullable<z.ZodNumber>;
    frozen: z.ZodBoolean;
    publicationId: z.ZodNullable<z.ZodString>;
}, z.core.$strict>;
export declare const DatasetFileAccessContextQuerySchema: z.ZodObject<{
    scope: z.ZodEnum<{
        PUBLISHED: "PUBLISHED";
        WORKING: "WORKING";
        REVIEWED: "REVIEWED";
        EDIT_BASE: "EDIT_BASE";
        GRANTED: "GRANTED";
    }>;
    component: z.ZodEnum<{
        SAMPLE: "SAMPLE";
        FULL: "FULL";
    }>;
    editOperation: z.ZodOptional<z.ZodEnum<{
        METADATA: "METADATA";
        PRICING: "PRICING";
        MATERIALS: "MATERIALS";
    }>>;
}, z.core.$strict>;
export declare const DatasetFileAccessPageQuerySchema: z.ZodObject<{
    afterId: z.ZodOptional<z.ZodString>;
    limit: z.ZodDefault<z.ZodCoercedNumber<unknown>>;
    scope: z.ZodEnum<{
        PUBLISHED: "PUBLISHED";
        WORKING: "WORKING";
        REVIEWED: "REVIEWED";
        EDIT_BASE: "EDIT_BASE";
        GRANTED: "GRANTED";
    }>;
    component: z.ZodEnum<{
        SAMPLE: "SAMPLE";
        FULL: "FULL";
    }>;
    editOperation: z.ZodOptional<z.ZodEnum<{
        METADATA: "METADATA";
        PRICING: "PRICING";
        MATERIALS: "MATERIALS";
    }>>;
    contentId: z.ZodString;
    contentGeneration: z.ZodUnion<readonly [z.ZodNumber, z.ZodPipe<z.ZodPipe<z.ZodString, z.ZodTransform<number, string>>, z.ZodNumber>]>;
    expectedWorkflowRevision: z.ZodOptional<z.ZodUnion<readonly [z.ZodNumber, z.ZodPipe<z.ZodPipe<z.ZodString, z.ZodTransform<number, string>>, z.ZodNumber>]>>;
}, z.core.$strict>;
export declare const DatasetFileDownloadBodySchema: z.ZodObject<{
    scope: z.ZodEnum<{
        PUBLISHED: "PUBLISHED";
        WORKING: "WORKING";
        REVIEWED: "REVIEWED";
        EDIT_BASE: "EDIT_BASE";
        GRANTED: "GRANTED";
    }>;
    component: z.ZodEnum<{
        SAMPLE: "SAMPLE";
        FULL: "FULL";
    }>;
    editOperation: z.ZodOptional<z.ZodEnum<{
        METADATA: "METADATA";
        PRICING: "PRICING";
        MATERIALS: "MATERIALS";
    }>>;
    contentId: z.ZodString;
    contentGeneration: z.ZodNumber;
    expectedWorkflowRevision: z.ZodOptional<z.ZodNumber>;
    memberId: z.ZodString;
    downloadIntentId: z.ZodPipe<z.ZodString, z.ZodTransform<string, string>>;
}, z.core.$strict>;
export declare const DatasetFileAccessMemberSchema: z.ZodObject<{
    id: z.ZodString;
    contentId: z.ZodString;
    component: z.ZodEnum<{
        SAMPLE: "SAMPLE";
        FULL: "FULL";
    }>;
    role: z.ZodEnum<{
        SENSOR: "SENSOR";
        PRIMARY: "PRIMARY";
        TRANSCRIPT: "TRANSCRIPT";
        ANNOTATION: "ANNOTATION";
        CALIBRATION: "CALIBRATION";
        DOCUMENTATION: "DOCUMENTATION";
    }>;
    relativePath: z.ZodNullable<z.ZodString>;
    groupId: z.ZodNullable<z.ZodString>;
    uploadObjectId: z.ZodString;
    originalFileName: z.ZodNullable<z.ZodString>;
    measuredSizeBytes: z.ZodString;
    membershipEvidenceId: z.ZodString;
    inspection: z.ZodObject<{
        securityState: z.ZodEnum<{
            CANCELLED: "CANCELLED";
            FAILED: "FAILED";
            UNKNOWN: "UNKNOWN";
            QUARANTINED: "QUARANTINED";
            PROCESSING: "PROCESSING";
            ACCEPTED: "ACCEPTED";
            BLOCKED: "BLOCKED";
            UNRECONCILED: "UNRECONCILED";
        }>;
        currentEvidenceId: z.ZodNullable<z.ZodString>;
        recordedOutcome: z.ZodEnum<{
            NONE: "NONE";
            UNKNOWN: "UNKNOWN";
            PASS: "PASS";
            FAIL: "FAIL";
        }>;
        current: z.ZodBoolean;
        eligibility: z.ZodLiteral<"NOT_EVALUATED">;
    }, z.core.$strict>;
}, z.core.$strict>;
export declare const DatasetFileAccessPageResponseSchema: z.ZodObject<{
    context: z.ZodObject<{
        datasetId: z.ZodString;
        scope: z.ZodEnum<{
            PUBLISHED: "PUBLISHED";
            WORKING: "WORKING";
            REVIEWED: "REVIEWED";
            EDIT_BASE: "EDIT_BASE";
            GRANTED: "GRANTED";
        }>;
        component: z.ZodEnum<{
            SAMPLE: "SAMPLE";
            FULL: "FULL";
        }>;
        editOperation: z.ZodNullable<z.ZodEnum<{
            METADATA: "METADATA";
            PRICING: "PRICING";
            MATERIALS: "MATERIALS";
        }>>;
        contentId: z.ZodString;
        contentGeneration: z.ZodNumber;
        workflowRevision: z.ZodNullable<z.ZodNumber>;
        frozen: z.ZodBoolean;
        publicationId: z.ZodNullable<z.ZodString>;
    }, z.core.$strict>;
    total: z.ZodNumber;
    items: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        contentId: z.ZodString;
        component: z.ZodEnum<{
            SAMPLE: "SAMPLE";
            FULL: "FULL";
        }>;
        role: z.ZodEnum<{
            SENSOR: "SENSOR";
            PRIMARY: "PRIMARY";
            TRANSCRIPT: "TRANSCRIPT";
            ANNOTATION: "ANNOTATION";
            CALIBRATION: "CALIBRATION";
            DOCUMENTATION: "DOCUMENTATION";
        }>;
        relativePath: z.ZodNullable<z.ZodString>;
        groupId: z.ZodNullable<z.ZodString>;
        uploadObjectId: z.ZodString;
        originalFileName: z.ZodNullable<z.ZodString>;
        measuredSizeBytes: z.ZodString;
        membershipEvidenceId: z.ZodString;
        inspection: z.ZodObject<{
            securityState: z.ZodEnum<{
                CANCELLED: "CANCELLED";
                FAILED: "FAILED";
                UNKNOWN: "UNKNOWN";
                QUARANTINED: "QUARANTINED";
                PROCESSING: "PROCESSING";
                ACCEPTED: "ACCEPTED";
                BLOCKED: "BLOCKED";
                UNRECONCILED: "UNRECONCILED";
            }>;
            currentEvidenceId: z.ZodNullable<z.ZodString>;
            recordedOutcome: z.ZodEnum<{
                NONE: "NONE";
                UNKNOWN: "UNKNOWN";
                PASS: "PASS";
                FAIL: "FAIL";
            }>;
            current: z.ZodBoolean;
            eligibility: z.ZodLiteral<"NOT_EVALUATED">;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    nextCursor: z.ZodNullable<z.ZodObject<{
        afterId: z.ZodOptional<z.ZodString>;
        limit: z.ZodDefault<z.ZodCoercedNumber<unknown>>;
        scope: z.ZodEnum<{
            PUBLISHED: "PUBLISHED";
            WORKING: "WORKING";
            REVIEWED: "REVIEWED";
            EDIT_BASE: "EDIT_BASE";
            GRANTED: "GRANTED";
        }>;
        component: z.ZodEnum<{
            SAMPLE: "SAMPLE";
            FULL: "FULL";
        }>;
        editOperation: z.ZodOptional<z.ZodEnum<{
            METADATA: "METADATA";
            PRICING: "PRICING";
            MATERIALS: "MATERIALS";
        }>>;
        contentId: z.ZodString;
        contentGeneration: z.ZodUnion<readonly [z.ZodNumber, z.ZodPipe<z.ZodPipe<z.ZodString, z.ZodTransform<number, string>>, z.ZodNumber>]>;
        expectedWorkflowRevision: z.ZodOptional<z.ZodUnion<readonly [z.ZodNumber, z.ZodPipe<z.ZodPipe<z.ZodString, z.ZodTransform<number, string>>, z.ZodNumber>]>>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare const DatasetFileObservationQuerySchema: z.ZodObject<{
    memberId: z.ZodString;
    evidenceId: z.ZodString;
    afterId: z.ZodOptional<z.ZodString>;
    limit: z.ZodDefault<z.ZodCoercedNumber<unknown>>;
    scope: z.ZodEnum<{
        PUBLISHED: "PUBLISHED";
        WORKING: "WORKING";
        REVIEWED: "REVIEWED";
        EDIT_BASE: "EDIT_BASE";
        GRANTED: "GRANTED";
    }>;
    component: z.ZodEnum<{
        SAMPLE: "SAMPLE";
        FULL: "FULL";
    }>;
    editOperation: z.ZodOptional<z.ZodEnum<{
        METADATA: "METADATA";
        PRICING: "PRICING";
        MATERIALS: "MATERIALS";
    }>>;
    contentId: z.ZodString;
    contentGeneration: z.ZodUnion<readonly [z.ZodNumber, z.ZodPipe<z.ZodPipe<z.ZodString, z.ZodTransform<number, string>>, z.ZodNumber>]>;
    expectedWorkflowRevision: z.ZodOptional<z.ZodUnion<readonly [z.ZodNumber, z.ZodPipe<z.ZodPipe<z.ZodString, z.ZodTransform<number, string>>, z.ZodNumber>]>>;
}, z.core.$strict>;
export declare const DatasetFileObservationSchema: z.ZodObject<{
    id: z.ZodString;
    evidenceId: z.ZodString;
    profileId: z.ZodString;
    result: z.ZodEnum<{
        FAILED: "FAILED";
        UNSUPPORTED: "UNSUPPORTED";
        NOT_CHECKED: "NOT_CHECKED";
        COMPLETE: "COMPLETE";
        STRUCTURE_ONLY: "STRUCTURE_ONLY";
    }>;
    source: z.ZodDiscriminatedUnion<[z.ZodObject<{
        kind: z.ZodLiteral<"PHYSICAL_OBJECT">;
        uploadObjectId: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"LOGICAL_ENTRY">;
        uploadObjectId: z.ZodString;
        inventoryId: z.ZodString;
        logicalEntryId: z.ZodString;
        locator: z.ZodDiscriminatedUnion<[z.ZodObject<{
            kind: z.ZodLiteral<"ARCHIVE_ENTRY">;
            path: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"WORKBOOK_SHEET">;
            sheetName: z.ZodString;
        }, z.core.$strict>], "kind">;
    }, z.core.$strict>], "kind">;
    measuredSizeBytes: z.ZodString;
    checksumSha256: z.ZodString;
    origin: z.ZodLiteral<"BACKEND_OBSERVED">;
    scope: z.ZodEnum<{
        EXACT_UPLOADED_OBJECT: "EXACT_UPLOADED_OBJECT";
        EXACT_ARCHIVE_ENTRY: "EXACT_ARCHIVE_ENTRY";
    }>;
    facts: z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodString, z.ZodNumber, z.ZodBoolean, z.ZodNull]>>;
}, z.core.$strict>;
export declare const DatasetFileObservationResponseSchema: z.ZodObject<{
    context: z.ZodObject<{
        datasetId: z.ZodString;
        scope: z.ZodEnum<{
            PUBLISHED: "PUBLISHED";
            WORKING: "WORKING";
            REVIEWED: "REVIEWED";
            EDIT_BASE: "EDIT_BASE";
            GRANTED: "GRANTED";
        }>;
        component: z.ZodEnum<{
            SAMPLE: "SAMPLE";
            FULL: "FULL";
        }>;
        editOperation: z.ZodNullable<z.ZodEnum<{
            METADATA: "METADATA";
            PRICING: "PRICING";
            MATERIALS: "MATERIALS";
        }>>;
        contentId: z.ZodString;
        contentGeneration: z.ZodNumber;
        workflowRevision: z.ZodNullable<z.ZodNumber>;
        frozen: z.ZodBoolean;
        publicationId: z.ZodNullable<z.ZodString>;
    }, z.core.$strict>;
    memberId: z.ZodString;
    evidenceId: z.ZodString;
    evidenceRelationship: z.ZodEnum<{
        CURRENT: "CURRENT";
        CAPTURED_FOR_MEMBERSHIP: "CAPTURED_FOR_MEMBERSHIP";
        CURRENT_AND_CAPTURED: "CURRENT_AND_CAPTURED";
    }>;
    total: z.ZodNumber;
    items: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        evidenceId: z.ZodString;
        profileId: z.ZodString;
        result: z.ZodEnum<{
            FAILED: "FAILED";
            UNSUPPORTED: "UNSUPPORTED";
            NOT_CHECKED: "NOT_CHECKED";
            COMPLETE: "COMPLETE";
            STRUCTURE_ONLY: "STRUCTURE_ONLY";
        }>;
        source: z.ZodDiscriminatedUnion<[z.ZodObject<{
            kind: z.ZodLiteral<"PHYSICAL_OBJECT">;
            uploadObjectId: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"LOGICAL_ENTRY">;
            uploadObjectId: z.ZodString;
            inventoryId: z.ZodString;
            logicalEntryId: z.ZodString;
            locator: z.ZodDiscriminatedUnion<[z.ZodObject<{
                kind: z.ZodLiteral<"ARCHIVE_ENTRY">;
                path: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                kind: z.ZodLiteral<"WORKBOOK_SHEET">;
                sheetName: z.ZodString;
            }, z.core.$strict>], "kind">;
        }, z.core.$strict>], "kind">;
        measuredSizeBytes: z.ZodString;
        checksumSha256: z.ZodString;
        origin: z.ZodLiteral<"BACKEND_OBSERVED">;
        scope: z.ZodEnum<{
            EXACT_UPLOADED_OBJECT: "EXACT_UPLOADED_OBJECT";
            EXACT_ARCHIVE_ENTRY: "EXACT_ARCHIVE_ENTRY";
        }>;
        facts: z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodString, z.ZodNumber, z.ZodBoolean, z.ZodNull]>>;
    }, z.core.$strict>>;
    nextCursor: z.ZodNullable<z.ZodObject<{
        memberId: z.ZodString;
        evidenceId: z.ZodString;
        afterId: z.ZodOptional<z.ZodString>;
        limit: z.ZodDefault<z.ZodCoercedNumber<unknown>>;
        scope: z.ZodEnum<{
            PUBLISHED: "PUBLISHED";
            WORKING: "WORKING";
            REVIEWED: "REVIEWED";
            EDIT_BASE: "EDIT_BASE";
            GRANTED: "GRANTED";
        }>;
        component: z.ZodEnum<{
            SAMPLE: "SAMPLE";
            FULL: "FULL";
        }>;
        editOperation: z.ZodOptional<z.ZodEnum<{
            METADATA: "METADATA";
            PRICING: "PRICING";
            MATERIALS: "MATERIALS";
        }>>;
        contentId: z.ZodString;
        contentGeneration: z.ZodUnion<readonly [z.ZodNumber, z.ZodPipe<z.ZodPipe<z.ZodString, z.ZodTransform<number, string>>, z.ZodNumber>]>;
        expectedWorkflowRevision: z.ZodOptional<z.ZodUnion<readonly [z.ZodNumber, z.ZodPipe<z.ZodPipe<z.ZodString, z.ZodTransform<number, string>>, z.ZodNumber>]>>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare const DatasetFileDownloadResponseSchema: z.ZodObject<{
    context: z.ZodObject<{
        datasetId: z.ZodString;
        scope: z.ZodEnum<{
            PUBLISHED: "PUBLISHED";
            WORKING: "WORKING";
            REVIEWED: "REVIEWED";
            EDIT_BASE: "EDIT_BASE";
            GRANTED: "GRANTED";
        }>;
        component: z.ZodEnum<{
            SAMPLE: "SAMPLE";
            FULL: "FULL";
        }>;
        editOperation: z.ZodNullable<z.ZodEnum<{
            METADATA: "METADATA";
            PRICING: "PRICING";
            MATERIALS: "MATERIALS";
        }>>;
        contentId: z.ZodString;
        contentGeneration: z.ZodNumber;
        workflowRevision: z.ZodNullable<z.ZodNumber>;
        frozen: z.ZodBoolean;
        publicationId: z.ZodNullable<z.ZodString>;
    }, z.core.$strict>;
    memberId: z.ZodString;
    downloadIntentId: z.ZodString;
    fileName: z.ZodString;
    measuredSizeBytes: z.ZodString;
    url: z.ZodURL;
    expiresAt: z.ZodString;
    expiresInSeconds: z.ZodLiteral<60>;
    disposition: z.ZodLiteral<"ATTACHMENT">;
}, z.core.$strict>;
export declare const DatasetFileBundleQuerySchema: z.ZodObject<{
    scope: z.ZodEnum<{
        PUBLISHED: "PUBLISHED";
        WORKING: "WORKING";
        REVIEWED: "REVIEWED";
        EDIT_BASE: "EDIT_BASE";
        GRANTED: "GRANTED";
    }>;
    contentId: z.ZodString;
    component: z.ZodEnum<{
        SAMPLE: "SAMPLE";
        FULL: "FULL";
    }>;
    expectedWorkflowRevision: z.ZodOptional<z.ZodUnion<readonly [z.ZodNumber, z.ZodPipe<z.ZodPipe<z.ZodString, z.ZodTransform<number, string>>, z.ZodNumber>]>>;
    contentGeneration: z.ZodUnion<readonly [z.ZodNumber, z.ZodPipe<z.ZodPipe<z.ZodString, z.ZodTransform<number, string>>, z.ZodNumber>]>;
    editOperation: z.ZodOptional<z.ZodEnum<{
        METADATA: "METADATA";
        PRICING: "PRICING";
        MATERIALS: "MATERIALS";
    }>>;
    downloadIntentId: z.ZodPipe<z.ZodString, z.ZodTransform<string, string>>;
}, z.core.$strict>;
export declare const DatasetFileBundleManifestSchema: z.ZodObject<{
    context: z.ZodObject<{
        datasetId: z.ZodString;
        scope: z.ZodEnum<{
            PUBLISHED: "PUBLISHED";
            WORKING: "WORKING";
            REVIEWED: "REVIEWED";
            EDIT_BASE: "EDIT_BASE";
            GRANTED: "GRANTED";
        }>;
        component: z.ZodEnum<{
            SAMPLE: "SAMPLE";
            FULL: "FULL";
        }>;
        editOperation: z.ZodNullable<z.ZodEnum<{
            METADATA: "METADATA";
            PRICING: "PRICING";
            MATERIALS: "MATERIALS";
        }>>;
        contentId: z.ZodString;
        contentGeneration: z.ZodNumber;
        workflowRevision: z.ZodNullable<z.ZodNumber>;
        frozen: z.ZodBoolean;
        publicationId: z.ZodNullable<z.ZodString>;
    }, z.core.$strict>;
    downloadIntentId: z.ZodString;
    fileName: z.ZodString;
    totalBytes: z.ZodString;
    files: z.ZodArray<z.ZodObject<{
        memberId: z.ZodString;
        path: z.ZodString;
        sizeBytes: z.ZodString;
    }, z.core.$strict>>;
}, z.core.$strict>;
export type DatasetFileBundleQuery = z.infer<typeof DatasetFileBundleQuerySchema>;
export type DatasetFileAccessSelection = z.infer<typeof DatasetFileAccessSelectionSchema>;
export type DatasetFileAccessContext = z.infer<typeof DatasetFileAccessContextSchema>;
export type DatasetFileAccessPageQuery = z.infer<typeof DatasetFileAccessPageQuerySchema>;
export type DatasetFileDownloadBody = z.infer<typeof DatasetFileDownloadBodySchema>;
export type DatasetFileObservationQuery = z.infer<typeof DatasetFileObservationQuerySchema>;
//# sourceMappingURL=access.schema.d.ts.map